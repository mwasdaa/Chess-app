package com.example.chesshelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class CaptureService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var tv: TextView
    private lateinit var reader: ImageReader
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private val ui = Handler(Looper.getMainLooper())
    private var busy = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("c", "Chess Helper", NotificationManager.IMPORTANCE_LOW))
        startForeground(
            1,
            Notification.Builder(this, "c").setContentTitle("Chess Helper aktif")
                .setSmallIcon(android.R.drawable.ic_menu_view).build(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
        if (i == null) { stopSelf(); return START_NOT_STICKY }
        @Suppress("DEPRECATION")
        val data = i.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mp = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        mp.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, ui)
        proj = mp
        val m = resources.displayMetrics
        reader = ImageReader.newInstance(m.widthPixels, m.heightPixels, PixelFormat.RGBA_8888, 2)
        vd = mp.createVirtualDisplay(
            "cap", m.widthPixels, m.heightPixels, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, null
        )
        showOverlay()
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        wm = getSystemService(WindowManager::class.java)
        tv = TextView(this).apply {
            text = "♞ Analisis"; textSize = 16f; setTextColor(Color.WHITE)
            setBackgroundColor(0xCC000000.toInt()); setPadding(32, 20, 32, 20)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = 24; lp.y = 200
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(tv, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) analyze()
            }
            true
        }
        wm.addView(tv, lp)
    }

    private fun analyze() {
        if (busy) return
        busy = true
        tv.visibility = View.INVISIBLE            // sembunyikan overlay agar tidak ikut tertangkap
        ui.postDelayed({
            Thread {
                val out = try { solve() } catch (e: Exception) { "⚠ ${e.message}" }
                ui.post { tv.text = out; tv.visibility = View.VISIBLE; busy = false }
            }.start()
        }, 400)
    }

    private fun solve(): String {
        val p = getSharedPreferences("p", 0)
        val key = p.getString("gkey", "") ?: ""
        if (key.isBlank()) return "Isi Gemini API key di menu Pengaturan"

        var got: android.media.Image? = null
        for (n in 1..10) { got = reader.acquireLatestImage(); if (got != null) break; Thread.sleep(150) }
        val img = got ?: return "Gagal menangkap layar"
        val pl = img.planes[0]
        val raw = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(pl.buffer)
        val bmp = Bitmap.createBitmap(raw, 0, 0, img.width, img.height)
        img.close()
        val jpg = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }.toByteArray()

        // 1) Gemini membaca posisi papan -> FEN
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
            .put(JSONObject().put("inline_data", JSONObject()
                .put("mime_type", "image/jpeg")
                .put("data", Base64.encodeToString(jpg, Base64.NO_WRAP))))
            .put(JSONObject().put("text",
                "Find the chess board in this screenshot and read the position exactly as shown. " +
                "The board may be flipped (check the file/rank labels or which colour is at the bottom). " +
                "Reply with ONLY the FEN piece-placement field (ranks 8 to 1 as seen from White's side), nothing else.")))))
        val model = p.getString("gmodel", "gemini-2.5-flash")
        val parts = JSONObject(
            http("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent", body.toString(),
                mapOf("x-goog-api-key" to key))
        ).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        val reply = (0 until parts.length()).joinToString(" ") { parts.getJSONObject(it).optString("text") }

        val place = Regex("([1-8prnbqkPRNBQK]+/){7}[1-8prnbqkPRNBQK]+").find(reply)?.value
            ?: return "Papan tidak terbaca, coba lagi"
        if (place.split("/").any { r -> r.sumOf { if (it.isDigit()) it - '0' else 1 } != 8 })
            return "Posisi tidak valid, coba lagi:\n$place"

        // 2) Stockfish menghitung langkah terbaik
        val fen = "$place ${if (p.getBoolean("white", true)) "w" else "b"} ${castling(place)} - 0 1"
        return best(fen, p.getInt("depth", 12)) + "\n[$place]"
    }

    private fun castling(p: String): String {
        fun row(s: String) = s.flatMap { if (it.isDigit()) List(it - '0') { '.' } else listOf(it) }
        val r = p.split("/"); val top = row(r[0]); val bot = row(r[7]); var c = ""
        if (bot[4] == 'K') { if (bot[7] == 'R') c += "K"; if (bot[0] == 'R') c += "Q" }
        if (top[4] == 'k') { if (top[7] == 'r') c += "k"; if (top[0] == 'r') c += "q" }
        return c.ifEmpty { "-" }
    }

    private fun best(fen: String, depth: Int): String {
        val f = URLEncoder.encode(fen, "UTF-8")
        try {
            val j = JSONObject(http("https://stockfish.online/api/s/v2.php?fen=$f&depth=$depth"))
            if (j.optBoolean("success")) {
                val mv = j.getString("bestmove").split(" ")[1]
                return fmt(mv) + "\n" + j.optString("continuation").split(" ").take(4).joinToString(" ")
            }
        } catch (e: Exception) { /* lanjut ke cadangan */ }
        val pv = JSONObject(http("https://lichess.org/api/cloud-eval?fen=$f")).getJSONArray("pvs").getJSONObject(0)
        val line = pv.getString("moves").split(" ")
        return fmt(line[0]) + "\n" + line.take(4).joinToString(" ")
    }

    private fun fmt(m: String) =
        "Langkah terbaik: ${m.substring(0, 2)} → ${m.substring(2, 4)}" + if (m.length > 4) " =${m[4].uppercaseChar()}" else ""

    private fun http(url: String, body: String? = null, h: Map<String, String> = emptyMap()): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 60000
        h.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) {
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code >= 400) throw Exception("HTTP $code: ${txt.take(120)}")
        return txt
    }

    override fun onDestroy() {
        if (::tv.isInitialized) try { wm.removeView(tv) } catch (e: Exception) {}
        vd?.release()
        if (::reader.isInitialized) reader.close()
        proj?.stop()
        super.onDestroy()
    }
}
