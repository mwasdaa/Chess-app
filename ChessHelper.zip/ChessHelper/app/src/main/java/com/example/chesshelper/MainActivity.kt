package com.example.chesshelper

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val info = TextView(this).apply {
            textSize = 16f
            setPadding(48, 48, 48, 24)
            text = "1. Menu ⋮ → Pengaturan: isi API key & pilih warnamu.\n\n" +
                "2. Tekan Mulai, izinkan rekam layar (pilih \"Seluruh layar\").\n\n" +
                "3. Buka aplikasi catur. Saat giliranmu, tekan tombol ♞ yang melayang (bisa digeser)."
        }
        val go = Button(this).apply { text = "Mulai analisis layar"; setOnClickListener { start() } }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(info); addView(go)
        })
    }

    override fun onCreateOptionsMenu(m: Menu): Boolean {
        m.add(0, 1, 0, "Mulai analisis")
        m.add(0, 2, 1, "Hentikan")
        m.add(0, 3, 2, "Pengaturan")
        m.add(0, 4, 3, "Tentang")
        return true
    }

    override fun onOptionsItemSelected(i: MenuItem): Boolean {
        when (i.itemId) {
            1 -> start()
            2 -> stopService(Intent(this, CaptureService::class.java))
            3 -> settings()
            4 -> AlertDialog.Builder(this).setTitle("Tentang")
                .setMessage("Papan dibaca lewat Gemini (vision); langkah dihitung Stockfish (GPLv3) via stockfish.online / Lichess.\n\nPakai untuk analisis dan latihan, bukan di partai live melawan manusia.")
                .setPositiveButton("OK", null).show()
        }
        return true
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Izinkan \"tampil di atas aplikasi lain\", lalu tekan Mulai lagi", Toast.LENGTH_LONG).show()
            return
        }
        startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java).putExtra("code", res).putExtra("data", data)
            )
            moveTaskToBack(true)
        }
    }

    private fun settings() {
        val p = getSharedPreferences("p", 0)
        fun field(hint: String, v: String) = EditText(this).apply { this.hint = hint; setText(v) }
        val key = field("Gemini API key", p.getString("gkey", "") ?: "")
        val model = field("Model", p.getString("gmodel", "gemini-2.5-flash") ?: "gemini-2.5-flash")
        val depth = field("Kedalaman mesin (1-15)", p.getInt("depth", 12).toString())
            .apply { inputType = InputType.TYPE_CLASS_NUMBER }
        val side = RadioGroup(this).apply {
            addView(RadioButton(context).apply { text = "Saya main Putih"; id = 1 })
            addView(RadioButton(context).apply { text = "Saya main Hitam"; id = 2 })
            check(if (p.getBoolean("white", true)) 1 else 2)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 16, 48, 0)
            addView(key); addView(model); addView(side); addView(depth)
        }
        AlertDialog.Builder(this).setTitle("Pengaturan").setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                p.edit()
                    .putString("gkey", key.text.toString().trim())
                    .putString("gmodel", model.text.toString().trim())
                    .putBoolean("white", side.checkedRadioButtonId == 1)
                    .putInt("depth", depth.text.toString().toIntOrNull()?.coerceIn(1, 15) ?: 12)
                    .apply()
            }
            .setNegativeButton("Batal", null).show()
    }
}
